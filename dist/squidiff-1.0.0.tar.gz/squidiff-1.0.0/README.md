<img src="squidiff_logo.png" width="80" /> **squidiff: Predicting cellular development and responses to perturbations using a diffusion model**
---
Squidiff is a diffusion model-based generative framework designed to predict transcriptomic changes across diverse cell types in response to a wide range of environmental changes.

<img src=squidiff_fig.png width="1000" />
